package de.hft.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import de.hft.model.Category;
import de.hft.model.PointOfInterest;
import de.hft.model.Route;

/**
 * This servlet returns a representation of all existing routes as a JSON string.
 * 
 * @author Marcel Bruse
 */
@WebServlet("/LoadAllRoutes")
public class LoadAllRoutes extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoadAllRoutes() {
        super();
    }
   
    /**
     * This servlet returns a representation of all existing routes as a JSON string.
     * 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        JSONObject routeObject;
        JSONArray routeArray = new JSONArray();
        List<Route> allRoutes;
        List<PointOfInterest> pointsOfInterestList;
        List<Category> categoryList;
        JSONArray categoryArray;
        JSONArray pointOfInterestArray;
        
        try {
        	allRoutes = Route.loadAllRoutes();
        	for (Route route : allRoutes) {
        		routeObject = new JSONObject();
        		routeObject.put("id", route.getId());
        		routeObject.put("name", route.getName());
        		routeObject.put("description", route.getDescription());
        		routeObject.put("estimatedTime", route.getEstimatedTime());
        		routeObject.put("rating", route.calculateRating());
        		
        		pointOfInterestArray = new JSONArray();
        		pointsOfInterestList = route.getPointsOfInterest();
        		for (PointOfInterest pointOfInterest : pointsOfInterestList) {
        			pointOfInterestArray.put(pointOfInterest.getId());
        		}
        		routeObject.put("pointsOfInterest", pointOfInterestArray);
        		
        		categoryArray = new JSONArray();
        		categoryList = route.getCategories();
        		for (Category category : categoryList) {
        			categoryArray.put(category.getId());
        		}
        		routeObject.put("categories", categoryArray);
        		
        		routeArray.put(routeObject);
        	}
        	
            out.println(routeArray.toString());
            out.flush();
        } finally {
            out.close();
        }
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
