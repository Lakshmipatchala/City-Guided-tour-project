package de.hft.servlets;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import de.hft.model.Picture;

/**
 * This servlet receives an uploaded file and stores it in the database. 
 * 
 * @author Marcel Bruse
 */
@WebServlet("/AddPictureToPointOfInterest")
public class AddPictureToPointOfInterest extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		String id = request.getParameter("id");
		try {
			if (ServletFileUpload.isMultipartContent(request)) {
				ServletFileUpload upload = new ServletFileUpload();
				FileItemIterator iter = upload.getItemIterator(request);

				while (iter.hasNext()) {

					FileItemStream item = iter.next();
					InputStream is = item.openStream();

					ByteArrayOutputStream buffer = new ByteArrayOutputStream();

					int read;
					byte[] data = new byte[16384];

					while ((read = is.read(data, 0, data.length)) != -1) {
					  buffer.write(data, 0, read);
					}

					buffer.flush();

					Picture picture = new Picture();
					picture.setFileName(item.getName());
					picture.setBytes(buffer.toByteArray());
					picture.setPointOfInterestId(Integer.parseInt(id));
					Picture.savePicture(picture);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
}