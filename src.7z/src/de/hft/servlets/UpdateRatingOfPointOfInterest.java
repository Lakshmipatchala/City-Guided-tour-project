package de.hft.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import de.hft.model.PointOfInterest;


/**
 * This servlet updates the user rating of a single point of interest.
 * 
 * @author Marcel Bruse
 */
@WebServlet("/UpdateRatingOfPointOfInterest")
public class UpdateRatingOfPointOfInterest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateRatingOfPointOfInterest() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    /**
     * This servlet updates the user rating of a single point of interest.
     * 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	String id = request.getParameter("id");
    	String ratingString = request.getParameter("rating");
    	
    	if (id != null && !id.isEmpty() && ratingString != null && !ratingString.isEmpty()) {
    		double rating = Double.parseDouble(ratingString);
    		PointOfInterest pointOfInterest = PointOfInterest.loadPointOfInterestById(id);
    		
    		if (pointOfInterest != null && pointOfInterest.isPersistent()) {
    			if (rating >= 1.0 && rating <= 5.0) {
    				double oldRating = pointOfInterest.getRating() * (double) pointOfInterest.getRatingCount();
    				int newRatingCount = pointOfInterest.getRatingCount() + 1;
    				
    				double newRating = (oldRating + rating) / (double) newRatingCount;
    				
    				pointOfInterest.setRating(newRating);
    				pointOfInterest.setRatingCount(newRatingCount);
    				PointOfInterest.update(pointOfInterest);        			    				
    			}
    		}
    	}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
