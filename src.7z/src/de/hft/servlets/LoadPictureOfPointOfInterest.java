package de.hft.servlets;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import de.hft.model.Picture;


/**
 * This servlet returns a picture of a single category.
 * 
 * @author Marcel Bruse
 */
@WebServlet("/LoadPictureOfPointOfInterest")
public class LoadPictureOfPointOfInterest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoadPictureOfPointOfInterest() {
        super();
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	int id = Integer.parseInt(request.getParameter("id"));
    	Picture picture = Picture.loadPictureById(id);
    	
		String filename = picture.getFileName();
		response.setContentType("image/jpeg");
		response.addHeader("Content-Disposition", "attachment; filename=\""	+ filename + "\"");
		byte[] buf = new byte[1024];
		try {
			int length = picture.getBytes().length;
			BufferedInputStream in = new BufferedInputStream(new ByteArrayInputStream(picture.getBytes()));
			ServletOutputStream out = response.getOutputStream();
			response.setContentLength(length);

			int l;
			while ((in != null) && ((l = in.read(buf)) != -1)) {
				out.write(buf, 0, l);
			}
			in.close();
			out.close();
		} catch (Exception exc) {
			exc.printStackTrace();
		}

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}