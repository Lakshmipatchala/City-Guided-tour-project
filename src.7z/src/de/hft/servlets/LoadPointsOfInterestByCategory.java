package de.hft.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import de.hft.model.Category;
import de.hft.model.PointOfInterest;
import de.hft.model.Route;

/**
 * This servlet returns a representation of a single point of interest by a category as a JSON string.
 * 
 * @author Marcel Bruse
 */
@WebServlet("/LoadPointsOfInterestByCategory")
public class LoadPointsOfInterestByCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoadPointsOfInterestByCategory() {
        super();
    }
   
    /**
     * This servlet returns a representation of a single point of interest by a category as a JSON string.
     * 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	String id = request.getParameter("id");
    	
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        JSONObject pointOfInterestObject;
        JSONArray pointOfInterestArray = new JSONArray();
        List<PointOfInterest> allPointsOfInterest;
        List<Category> categoryList;
        JSONArray categoryArray;
        
        try {
        	allPointsOfInterest = PointOfInterest.loadPointsOfInterestByCategory(id);
        	for (PointOfInterest pointOfInterest : allPointsOfInterest) {
        		pointOfInterestObject = new JSONObject();
        		pointOfInterestObject.put("id", pointOfInterest.getId());
        		pointOfInterestObject.put("name", pointOfInterest.getName());
        		pointOfInterestObject.put("description", pointOfInterest.getDescription());
        		pointOfInterestObject.put("longitude", pointOfInterest.getLongitude());
        		pointOfInterestObject.put("latitude", pointOfInterest.getLatitude());
        		pointOfInterestObject.put("postalAddress", pointOfInterest.getPostalAddress());
        		pointOfInterestObject.put("rating", pointOfInterest.getRating());
        		
        		categoryArray = new JSONArray();
        		categoryList = pointOfInterest.getCategories();
        		for (Category category : categoryList) {
        			categoryArray.put(category.getId());
        		}
        		pointOfInterestObject.put("categories", categoryArray);
        		
        		pointOfInterestArray.put(pointOfInterestObject);
        	}
        	
            out.println(pointOfInterestArray.toString());
            out.flush();
        } finally {
            out.close();
        }
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}

