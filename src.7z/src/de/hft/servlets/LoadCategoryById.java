package de.hft.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import de.hft.model.Category;

/**
 * This servlet returns a representation of a single category as a JSON string.
 * 
 * @author Marcel Bruse
 */
@WebServlet("/LoadCategoryById")
public class LoadCategoryById extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoadCategoryById() {
        super();
    }
    
    /**
     * This servlet returns a representation of a single category as a JSON string.
     * 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	String id = request.getParameter("id");
    	
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        JSONObject categoryObject = new JSONObject();
        
        try {
        	if (id.isEmpty()) {
        		out.print("{}");
        	} else {
        		Category category = Category.loadCategoryById(id);
        		categoryObject.put("id", category.getId());
        		categoryObject.put("name", category.getName());
        		
        		out.println(categoryObject.toString());        		
        	}
            out.flush();
        } finally {
            out.close();
        }
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
