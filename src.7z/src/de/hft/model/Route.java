package de.hft.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import org.json.JSONArray;
import org.json.JSONObject;

import de.hft.data.Database;

/**
 * This class describes a route with all its attributes and methods. A route consists of
 * several points of interest. The route should have an id, a name and a description. You
 * can give an estimated time in hours to give the user an indication how long this tour
 * will take.
 * 
 * @author Marcel Bruse
 */
@ManagedBean(name = "routeBean")
@RequestScoped
public class Route {

	/** The unique id of the route. */
	private int id;
	
	/** The name of the route */
	private String name;
	
	/** The description of the route. */
	private String description;
	
	/** The list of containing points of interest. */
	private LinkedList<PointOfInterest> pointOfInterestList;
	
	/** The list of assigned categories. */
	private ArrayList<Category> categories;
	
	/** The time estimated it will take to walk this route. */
	private double estimatedTime;
	
	/**
	 * The standard constructor 
	 */
	public Route() {
		pointOfInterestList = new LinkedList<PointOfInterest>();
		categories = new ArrayList<Category>();
		estimatedTime = 0.0;
	}
	
	/**
	 * A constructor.
	 * 
	 * @param id the id of the route.
	 * @param name the name of the route.
	 * @param description the description of the route.
	 */
	public Route(int id, String name, String description) {
		this();
		this.id = id;
		this.name = name;
		this.description = description;
	}
	
	/**
	 * Returns the id of the route.
	 * 
	 * @return the id of the route.
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Sets the id of the route.
	 * 
	 * @param id the id of the route.
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Returns the name of the route.
	 * 
	 * @return the name of the route.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name of the route.
	 * 
	 * @param name the name of the route.
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Returns the description of the route.
	 * 
	 * @return the description of the route.
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the description of the route.
	 * 
	 * @param description the description of the route.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Adds a point of interest to the route.
	 * 
	 * @param pointOfInterest a point of interest to be added.
	 */
	public void addPointOfInterest(PointOfInterest pointOfInterest) {
		pointOfInterestList.add(pointOfInterest);
	}
	
	/**
	 * Removes a point of interest from the route.
	 * 
	 * @param pointOfInterest a point of interest to be removed.
	 */
	public void removePointOfInterest(PointOfInterest pointOfInterest) {
		pointOfInterestList.remove(pointOfInterest);
	}
	
	/**
	 * Returns a list of points of interest.
	 * 
	 * @return a list of points of interest.
	 */
	public List<PointOfInterest> getPointsOfInterest() {
		return pointOfInterestList;
	}
	
	/**
	 * Checks whether the route is persistent or not.
	 * 
	 * @return true, if the route is persistent.
	 */
	public boolean isPersistent() {
		return id > 0;
	}

	/**
	 * Creates a JSON string out of all existing routes. 
	 * 
	 * @return a JSON string out of all existing routes. 
	 */
	public static JSONArray loadRouteIndex() {
		ResultSet resultSet = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject;
		try {
			resultSet = Database.executeQuery("SELECT * FROM Routes");
			while (resultSet.next()) {
				jsonObject = new JSONObject();
				int id = Integer.parseInt(resultSet.getString("id").trim());
				jsonObject.put("id", id);
				jsonObject.put("name", resultSet.getString("name").trim());
				jsonArray.put(jsonObject);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null ) { try {resultSet.getStatement().close(); } catch (Exception e) {} }
			if (resultSet != null ) { try {resultSet.close(); } catch (Exception e) {} }
		}
		
		return jsonArray;
	}

	/**
	 * Loads all existing routes from the underlying database.
	 * 
	 * @return a list of all existing routes.
	 */
	public static List<Route> loadAllRoutes() {
		ArrayList<Route> routeList = new ArrayList<Route>();
		Route route;
		ResultSet resultSet = null;
		ResultSet innerResultSet = null;
		
		int aId;
		String aName;
		String aDescription;
		String pointOfInterestId;
		PointOfInterest pointOfInterest;
		String categoryId;
		Category category;
		double aEstimatedTime;
		
		try {
			resultSet = Database.executeQuery("SELECT * FROM Routes");
			while (resultSet.next()) {
				aId = Integer.parseInt(resultSet.getString("id"));
				aName = resultSet.getString("name").trim();
				aDescription = resultSet.getString("description").trim();
				aEstimatedTime = Double.parseDouble(resultSet.getString("estimatedTime"));
				
				route = new Route();
				route.setId(aId);
				route.setName(aName);
				route.setDescription(aDescription);
				route.setEstimatedTime(aEstimatedTime);
				
				innerResultSet = Database.executeQuery("SELECT * FROM Mapping WHERE routeId = " + aId);
				while (innerResultSet.next()) {
					pointOfInterestId = innerResultSet.getString("poiId").trim();
					pointOfInterest = PointOfInterest.loadPointOfInterestById(pointOfInterestId);
					route.addPointOfInterest(pointOfInterest);
				}
				innerResultSet.getStatement().close();
				innerResultSet.close();
				
				innerResultSet = Database.executeQuery("SELECT * FROM RouteCategories WHERE routeId = " + aId);
				while (innerResultSet.next()) {
					categoryId = innerResultSet.getString("categoryId").trim();
					category = Category.loadCategoryById(categoryId);
					route.addCategory(category);
				}
				innerResultSet.getStatement().close();
				innerResultSet.close();
				
				routeList.add(route);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null ) { try {resultSet.getStatement().close(); } catch (Exception e) {} }
			if (resultSet != null ) { try {resultSet.close(); } catch (Exception e) {} }
			if (innerResultSet != null ) { try {innerResultSet.getStatement().close(); } catch (Exception e) {} }
			if (innerResultSet != null ) { try {innerResultSet.close(); } catch (Exception e) {} }
		}
		
		return routeList;
	}
	
	/**
	 * Loads a route from the database by its id.
	 * 
	 * @param id the id of the route to be loaded.
	 * @return the route to be loaded.
	 */
	public static Route loadRouteById(String id) {
		ResultSet resultSet = null;
		ResultSet innerResultSet = null;
		
		int aId;
		String aName;
		String aDescription;
		String pointOfInterestId;
		PointOfInterest pointOfInterest;
		String categoryId;
		Category category;
		double aEstimatedTime;
		Route route = null;
		
		try {
			resultSet = Database.executeQuery("SELECT * FROM Routes WHERE id = " + id);

			resultSet.next();
			aId = Integer.parseInt(resultSet.getString("id"));
			aName = resultSet.getString("name").trim();
			aDescription = resultSet.getString("description").trim();
			aEstimatedTime = Double.parseDouble(resultSet.getString("estimatedTime"));
			
			route = new Route();
			route.setId(aId);
			route.setName(aName);
			route.setDescription(aDescription);
			route.setEstimatedTime(aEstimatedTime);
			
			innerResultSet = Database.executeQuery("SELECT * FROM Mapping WHERE routeId = " + aId + " ORDER BY id");
			while (innerResultSet.next()) {
				pointOfInterestId = innerResultSet.getString("poiId").trim();
				pointOfInterest = PointOfInterest.loadPointOfInterestById(pointOfInterestId);
				route.addPointOfInterest(pointOfInterest);
			}
			innerResultSet.getStatement().close();
			innerResultSet.close();
			
			innerResultSet = Database.executeQuery("SELECT * FROM RouteCategories WHERE routeId = " + aId);
			while (innerResultSet.next()) {
				categoryId = innerResultSet.getString("categoryId").trim();
				category = Category.loadCategoryById(categoryId);
				route.addCategory(category);
			}
			innerResultSet.getStatement().close();
			innerResultSet.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null ) { try {resultSet.getStatement().close(); } catch (Exception e) {} }
			if (resultSet != null ) { try {resultSet.close(); } catch (Exception e) {} }
			if (innerResultSet != null ) { try {innerResultSet.getStatement().close(); } catch (Exception e) {} }
			if (innerResultSet != null ) { try {innerResultSet.close(); } catch (Exception e) {} }
		}
		
		return route;
	}
	
	/**
	 * Loads all routes from the database that are belonging to a particular category.
	 * 
	 * @param id the id of the category.
	 * @return a list of all routes that are belonging to a particular category.
	 */
	public static List<Route> loadRoutesByCategory(String id) {
		ArrayList<Route> routeList = new ArrayList<Route>();
		Route route;
		ResultSet resultSet = null;
		ResultSet innerResultSet = null;
		
		int aId;
		String aName;
		String aDescription;
		String pointOfInterestId;
		PointOfInterest pointOfInterest;
		String categoryId;
		Category category;
		double aEstimatedTime;
		
		try {
			String sqlStatement = "SELECT * FROM Routes WHERE id IN (SELECT routeId FROM RouteCategories WHERE categoryId = " + id + ")";
			resultSet = Database.executeQuery(sqlStatement);
			while (resultSet.next()) {
				aId = Integer.parseInt(resultSet.getString("id"));
				aName = resultSet.getString("name").trim();
				aDescription = resultSet.getString("description").trim();
				aEstimatedTime = Double.parseDouble(resultSet.getString("estimatedTime"));
				
				route = new Route();
				route.setId(aId);
				route.setName(aName);
				route.setDescription(aDescription);
				route.setEstimatedTime(aEstimatedTime);
				
				innerResultSet = Database.executeQuery("SELECT * FROM Mapping WHERE routeId = " + aId);
				while (innerResultSet.next()) {
					pointOfInterestId = innerResultSet.getString("poiId").trim();
					pointOfInterest = PointOfInterest.loadPointOfInterestById(pointOfInterestId);
					route.addPointOfInterest(pointOfInterest);
				}
				innerResultSet.getStatement().close();
				innerResultSet.close();
				
				innerResultSet = Database.executeQuery("SELECT * FROM RouteCategories WHERE routeId = " + aId);
				while (innerResultSet.next()) {
					categoryId = innerResultSet.getString("categoryId").trim();
					category = Category.loadCategoryById(categoryId);
					route.addCategory(category);
				}
				innerResultSet.getStatement().close();
				innerResultSet.close();
				
				routeList.add(route);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null ) { try {resultSet.getStatement().close(); } catch (Exception e) {} }
			if (resultSet != null ) { try {resultSet.close(); } catch (Exception e) {} }
			if (innerResultSet != null ) { try {innerResultSet.getStatement().close(); } catch (Exception e) {} }
			if (innerResultSet != null ) { try {innerResultSet.close(); } catch (Exception e) {} }
		}
		
		return routeList;
	}
	
	/**
	 * Saves a given route in the database. 
	 * 
	 * @param route a route to be saved in the database.
	 */
	public static void save(Route route) {
		String sqlStatement;
		
		try {
			sqlStatement = "INSERT INTO Routes (name, description, estimatedTime) VALUES(" +
					"'" + route.name + "', " +
					"'" + route.description + "', " +
					+ route.estimatedTime +");";
			Database.executeUpdate(sqlStatement);
			
			sqlStatement = "DELETE FROM RoutePointsOfInterest WHERE routeId = " + route.id;
			Database.executeUpdate(sqlStatement);
			
			for (PointOfInterest pointOfInterest : route.getPointsOfInterest()) {
				sqlStatement = "INSERT INTO RoutePointsOfInterest (routeId, poiId) VALUES(" +
						+ route.getId() + "," +
						+ pointOfInterest.getId() + ")";
				Database.executeUpdate(sqlStatement);
			}
			
			for (Category category : route.getCategories()) {
				sqlStatement = "INSERT INTO RouteCategories (routeId, categoryId) VALUES(" +
						+ route.id + "," +
						+ category.getId() + ")";
				Database.executeUpdate(sqlStatement);
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Updates a route in the database.
	 * 
	 * @param route a route to be updated.
	 */
	public static void update(Route route) {
		String sqlStatement;
		
		try {
			sqlStatement = "UPDATE Routes " +
					"SET name = '" + route.name + "', " + 
					"description = '" + route.description + "', " +
					"estimatedTime = " + route.estimatedTime + " " +
					"WHERE id = " + route.id;
			Database.executeUpdate(sqlStatement);
			
			sqlStatement = "DELETE FROM Mapping WHERE routeId = " + route.id;
			Database.executeUpdate(sqlStatement);
			
			for (PointOfInterest pointOfInterest : route.getPointsOfInterest()) {
				sqlStatement = "INSERT INTO Mapping (routeId, poiId) VALUES(" +
						+ route.getId() + "," +
						+ pointOfInterest.getId() + ")";
				Database.executeUpdate(sqlStatement);
			}
			
			sqlStatement = "DELETE FROM RouteCategories WHERE routeId = " + route.id;
			Database.executeUpdate(sqlStatement);
			
			for (Category category : route.getCategories()) {
				sqlStatement = "INSERT INTO RouteCategories (routeId, categoryId) VALUES(" +
						+ route.id + "," +
						+ category.getId() + ")";
				Database.executeUpdate(sqlStatement);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Deletes a given route from the database.
	 * 
	 * @param route a route to be deleted.
	 */
	public static void delete(Route route) {
		String sqlStatement = "DELETE FROM Routes WHERE id = " + route.getId();
		
		try {
			Database.executeUpdate(sqlStatement);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Returns a list of all assigned categories.
	 * 
	 * @return a list of all assigned categories.
	 */
	public ArrayList<Category> getCategories() {
		return categories;
	}

	/**
	 * Sets the list of categories associated with the route.
	 * 
	 * @param categories the list of categories.
	 */
	public void setCategories(ArrayList<Category> categories) {
		this.categories = categories;
	}
	
	/**
	 * Adds a given category to the list of categories. Meaning, that
	 * the route is associated with the category.
	 * @param category
	 */
	public void addCategory(Category category) {
		categories.add(category);
	}
	
	/**
	 * Removes a given category from the category list. Meaning, that
	 * the route is no more associated with the category.
	 * 
	 * @param category the category to remove.
	 */
	public void removeCategory(Category category) {
		categories.remove(category);
	}
	
	/**
	 * Changes the order of the points of interest on the route by
	 * moving the given point of interest one position up in the
	 * list.
	 * 
	 * @param index The index of the point of interest to move up in the list.
	 */
	public void moveUpPointOfInterest(int index) {
        if (index > 0) {
            PointOfInterest tmp = pointOfInterestList.remove(index);
            pointOfInterestList.add(index - 1, tmp);
        }
	}
	
	/**
	 * Changes the order of the points of interest on the route by
	 * moving the given point of interest one position down in the
	 * list.
	 * 
	 * @param index The index of the point of interest to move up in the list.
	 */
	public void moveDownPointOfInterest(int index) {
        if (index < pointOfInterestList.size() - 1) {
            PointOfInterest tmp = pointOfInterestList.remove(index);
            pointOfInterestList.add(index + 1, tmp);
        }
	}

	/**
	 * Returns the estimated time of this route.
	 * 
	 * @return the estimated time of this route.
	 */
	public double getEstimatedTime() {
		return estimatedTime;
	}

	/**
	 * Sets the estimated time of this route.
	 * 
	 * @param estimatedTime the estimated time of this route.
	 */
	public void setEstimatedTime(double estimatedTime) {
		this.estimatedTime = estimatedTime;
	}
	
	/**
	 * Calculates the rating of the route based on the ratings of the consisting
	 * points of interest.
	 * 
	 * @return the rating of the route.
	 */
	public double calculateRating() {
		double routeRating = 0.0;
		if (pointOfInterestList.size() > 0) {
			for (PointOfInterest pointOfInterest : pointOfInterestList) {
				routeRating += pointOfInterest.getRating();
			}
			routeRating = routeRating / pointOfInterestList.size();		
		}
		return routeRating;
	}
	
}
