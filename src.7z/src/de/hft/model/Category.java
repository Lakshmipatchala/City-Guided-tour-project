package de.hft.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import de.hft.data.Database;

/**
 * This class implements the model of the category. A category is useful to
 * filter points of interest and routes.
 * 
 * @author Marcel Bruse
 */
@ManagedBean(name = "category")
@RequestScoped
public class Category {

	/** The id of the category. It will be given by the database. */
	private int id;
	
	/** The name of the category. */
	private String name;
	
	/**
	 * The standard constructor
	 */
	public Category() {
	}
	
	/**
	 * A constructor for the category.
	 * 
	 * @param id the id of the category.
	 * @param name the name of the category.
	 */
	public Category(int id, String name) {
		this.id = id;
		this.name = name;
	}

	/**
	 * Returns the id of the category.
	 * 
	 * @return the id of the category.
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id of the category.
	 * 
	 * @param id the id of the category.
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Returns the name of the category.
	 * 
	 * @return the name of the category.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name of the category.
	 * 
	 * @param name the name of the category.
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Checks whether the category is persistent already or not.
	 * 
	 * @return true, if the category is persistent already.
	 */
	public boolean isPersistent() {
		return id > 0;
	}
	
	/**
	 * Checks whether the category equals another category.
	 * 
	 * @param category another category.
	 * @return true, if the category equals another category.
	 */
	public boolean equals(Category category) {
		if (category != null) {
			return category.id == this.id;			
		} else {
			return false;
		}
	}
	
	/**
	 * Loads a category by its id from the database.
	 * 
	 * @param id the id of the category to be loaded.
	 * @return the loaded category.
	 */
	public static Category loadCategoryById(String id) {
		ResultSet resultSet = null;
		Category category = null;
		try {
			int aId = 0;
			String aName = null;
			
			resultSet = Database.executeQuery("SELECT * FROM Categories WHERE id = " + id);
			while (resultSet.next()) {
				aId = Integer.parseInt(resultSet.getString("id"));
				aName = resultSet.getString("name").trim();
			}
			
			category = new Category();
			category.setId(aId);
			category.setName(aName);
			
			resultSet.getStatement().close();
			resultSet.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) { try { resultSet.getStatement().close(); } catch (SQLException e) {} }
			if (resultSet != null) { try { resultSet.close(); } catch (SQLException e) {} }
		}
		
		return category;
	}
	
	/**
	 * Loads all existing categories.
	 * 
	 * @return a list of all existing categories.
	 */
	public static List<Category> loadAllCategories() {
		ResultSet resultSet = null;
		List<Category> categoryList = new ArrayList<Category>();
		Category category;
		try {
			int aId = 0;
			String aName = null;
			
			resultSet = Database.executeQuery("SELECT * FROM Categories");
			while (resultSet.next()) {
				aId = Integer.parseInt(resultSet.getString("id"));
				aName = resultSet.getString("name").trim();
				
				category = new Category();
				category.setId(aId);
				category.setName(aName);
				
				categoryList.add(category);
			}
			
			resultSet.getStatement().close();
			resultSet.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) { try { resultSet.getStatement().close(); } catch (SQLException e) {} }
			if (resultSet != null) { try { resultSet.close(); } catch (SQLException e) {} }
		}
		
		return categoryList;		
	}
	
	/**
	 * Saves a given category.
	 * 
	 * @param category a category to save.
	 */
	public static void save(Category category) {
		String sqlStatement = "INSERT INTO Categories (name) VALUES('" + category.name + "');";
		try {
			Database.executeUpdate(sqlStatement);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Updates a given category.
	 * 	
	 * @param category the category to be updated.
	 */
	public static void update(Category category) {
		String sqlStatement = "UPDATE Categories " +
				"SET name = '" + category.name + "' " +
				"WHERE id = " + category.id;
		try {
			Database.executeUpdate(sqlStatement);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Deletes a given category.
	 * 
	 * @param category the category to be deleted.
	 */
	public static void delete(Category category) {
		String sqlStatement = "DELETE FROM Categories WHERE id = " + category.getId();
		
		try {
			Database.executeUpdate(sqlStatement);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
