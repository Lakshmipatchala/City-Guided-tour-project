package de.hft.model;

import java.io.ByteArrayInputStream;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import de.hft.data.Database;

/**
 * Instances of this class are representing uploaded picture files.
 * Pictures are assigned to points of interest.
 * 
 * @author Marcel Bruse
 */

@ManagedBean(name = "pictureBean")
@RequestScoped
public class Picture {
	
	/** The unique id of the picture */
	private int id;
	
	/** The file name of the picture */
	private String fileName;
	
	/** The picture itself */
	private byte[] bytes;
	
	/** The assigned point of interest */
	private int pointOfInterestId;
	
	/** A temporary BLOB representation of the picture */
	private Blob blob;
	
	/** 
	 * The standard constructor
	 **/
	public Picture() {		
	}
	
	/**
	 *  A constructor 
	 **/
	public Picture(int id, String fileName) {
		this.id = id;
		this.fileName = fileName;
	}
	
	/**
	 * Returns the id of the picture.
	 * 
	 * @return the id of the picture.
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Sets the id of the picture.
	 * 
	 * @param id the id of the picture.
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Returns the file name of the picture.
	 * 
	 * @return the file name of the picture.
	 */
	public String getFileName() {
		return fileName;
	}
	
	/**
	 * Sets the file name of the picture.
	 * 
	 * @param fileName the file name of the picture.
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * Returns the bytes of the picture.
	 * 
	 * @return the bytes of the picture.
	 */
	public byte[] getBytes() {
		return bytes;
	}

	/**
	 * Sets the bytes of the pictures.
	 * 
	 * @param bytes the bytes of the pictures.
	 */
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}

	/**
	 * Loads a picture from the database by giving the id of the picture.
	 * 
	 * @param id the id of the picture to be loaded.
	 * @return the picture to be loaded.
	 */
	public static Picture loadPictureById(int id) {
		String sqlStatement = "SELECT * FROM PointOfInterestPictures WHERE id = " + id;
		Picture picture = null;
		ResultSet resultSet = null;
		try {
			resultSet = Database.executeQuery(sqlStatement);
			resultSet.next();
			Blob pictureBytes = resultSet.getBlob("picture");
			byte[] bytes = pictureBytes.getBytes(1, (int) pictureBytes.length());
			String fileName = resultSet.getString("fileName").trim();
			
			picture = new Picture();
			picture.setId(id);
			picture.setFileName(fileName);
			picture.setBytes(bytes);
			picture.setBlob(pictureBytes);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) { try { resultSet.getStatement().close(); } catch (SQLException e) {} }
			if (resultSet != null) { try { resultSet.close(); } catch (SQLException e) {} }
		}
		
		return picture;
	}
	
	/**
	 * Saves a given picture in the database.
	 * 
	 * @param picture the picture to be saved.
	 */
	public static void savePicture(Picture picture) {
        PreparedStatement preparedStatement;
        byte[] bytes = picture.getBytes();
        ByteArrayInputStream stream = new ByteArrayInputStream(bytes);
        
        String sqlStatement;
        try {
        	if (picture.id == 0) {       		
        		sqlStatement = "INSERT INTO PointOfInterestPictures (poiId, fileName, picture) VALUES (?, ?, ?)";
        		Database.openConnection();
        		preparedStatement = Database.getConnection().prepareStatement(sqlStatement);
        		preparedStatement.setString(1, String.valueOf(picture.getPointOfInterestId()));
        		preparedStatement.setString(2, picture.getFileName());
        		preparedStatement.setBinaryStream(3, stream, bytes.length);
        		preparedStatement.execute();
        		preparedStatement.close();
        	}
        	
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Deletes a given picture from the database.
	 * 
	 * @param picture the picture to be deleted.
	 */
	public static void deletePicture(Picture picture) {
        String sqlStatement;
        try {
        	sqlStatement = "DELETE FROM PointOfInterestPictures WHERE id = " + picture.getId();
        	Database.executeUpdate(sqlStatement);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Returns the id of the assigned point of interest.
	 * 
	 * @return the id of the assigned point of interest.
	 */
	public int getPointOfInterestId() {
		return pointOfInterestId;
	}

	/**
	 * Sets the id of the assigned point of interest.
	 * @param pointOfInterestId the id of the assigned point of interest.
	 */
	public void setPointOfInterestId(int pointOfInterestId) {
		this.pointOfInterestId = pointOfInterestId;
	}

	/**
	 * Returns the BLOB of the picture.
	 * 
	 * @return the BLOB of the picture.
	 */
	public Blob getBlob() {
		return blob;
	}

	/**
	 * Sets the BLOB of the picture.
	 * 
	 * @param blob the BLOB of the picture.
	 */
	public void setBlob(Blob blob) {
		this.blob = blob;
	}
}
