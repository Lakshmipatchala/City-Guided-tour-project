package de.hft.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import de.hft.data.Database;

/**
 * This class describes a point of interest with all its attributes and methods. A point of interest
 * is a important or interesting point on the map. A point of interest has at least an id, a name
 * and a description. It can be located by a latitude and longitude or by a postal address. It is
 * possible to attach several media types to the point of interest like pictures, audio and video
 * files.
 * 
 * @author Marcel Bruse
 */
@ManagedBean(name = "pointOfInterestBean")
@RequestScoped
public class PointOfInterest {

	/** The unique id of the point of interest. */
	private int id;
	
	/** The name of the point of interest. */
	private String name;
	
	/** The description of the point of interest. */
	private String description;
	
	/** The longitude of the location of the point of interest. */
	private double longitude;
	
	/** The latitude of the location of the point of interest. */
	private double latitude;
	
	/** The rating of the point of interest. */
	private double rating;
	
	/** The amount of ratings done by the users. */
	private int ratingCount;
	
	/** The attached picture files. */
	private ArrayList<Picture> pictures;
	
	/** The postal address of the point of interest. */
	private String postalAddress;
	
	/** The attached categories, which the point of interest belongs to. */
	private ArrayList<Category> categories;
	
	/**
	 * The standard constructor.
	 */
	public PointOfInterest() {
		categories = new ArrayList<Category>();
		pictures = new ArrayList<Picture>();
		rating = 0.0;
		ratingCount = 0;
	}
	
	/**
	 * A constructor.
	 * 
	 * @param id the unique id of the point of interest.
	 * @param name the name of the point of interest.
	 * @param description the description of the point of interest.
	 * @param longitude the longitude of the point of interest.
	 * @param latitude the latitude of the point of interest.
	 * @param postalAddress the postal address of the point of interest.
	 * @param rating the user rating of the point of interest.
	 * @param ratingCount the count of given ratings.
	 */
	public PointOfInterest(int id, 
			String name, 
			String description, 
			int longitude, 
			int latitude, 
			String postalAddress, 
			double rating, 
			int ratingCount) {
		this();
		this.id = id;
		this.name = name;
		this.description = description;
		this.longitude = longitude;
		this.latitude = latitude;
		this.postalAddress = postalAddress;
		this.rating = rating;
		this.setRatingCount(ratingCount);
	}
	
	/**
	 * Returns the name of the point of interest.
	 * 
	 * @return the name of the point of interest.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name of the point of interest.
	 * 
	 * @param name the name of the point of interest.
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Returns the description of the point of interest.
	 * 
	 * @return the description of the point of interest.
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the description of the point of interest.
	 * 
	 * @param description the description of the point of interest.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Returns the longitude of the point of interest.
	 * 
	 * @return the longitude of the point of interest.
	 */
	public double getLongitude() {
		return longitude;
	}
	
	/**
	 * Sets the longitude of the point of interest.
	 * 
	 * @param longitude the longitude of the point of interest.
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	
	/**
	 * Returns the latitude of the point of interest.
	 * 
	 * @return the latitude of the point of interest.
	 */
	public double getLatitude() {
		return latitude;
	}
	
	/**
	 * Sets the latitude of the point of interest.
	 * 
	 * @param latitude the latitude of the point of interest.
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/**
	 * Returns the id of the point of interest.
	 * 
	 * @return the id of the point of interest.
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id of the point of interest.
	 * 
	 * @param id the id of the point of interest.
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Adds a category to the point of interest.
	 * 
	 * @param category the category to be added.
	 */
	public void addCategory(Category category) {
		categories.add(category);
	}
	
	/**
	 * Removes a category from a point of interest.
	 * 
	 * @param category the category to be removed.
	 */
	public void removeCategory(Category category) {
		categories.remove(category);
	}
	
	/**
	 * Returns a list of categories assigned to this point of interest.
	 * 
	 * @return a list of categories assigned to this point of interest.
	 */
	public List<Category> getCategories() {
		return categories;
	}
	
	/**
	 * Checks whether the point of interest is persistent or not.
	 * 
	 * @return true, if the point of interest is persistent.
	 */
	public boolean isPersistent() {
		return id > 0;
	}
	
	/**
	 * Checks whether this point of interest equals another point of interest.
	 * 
	 * @param pointOfInterest another point of interest.
	 * @return true, if this point of interest equals another point of interest.
	 */
	public boolean equals(PointOfInterest pointOfInterest) {
		return this.id == pointOfInterest.getId();
	}
	
	/**
	 * Loads a point of interest from the database by its id.
	 * 
	 * @param id the id of the point of interest to be loaded.
	 * @return the point of interest to be loaded.
	 */
	public static PointOfInterest loadPointOfInterestById(String id) {
		ResultSet poiResultSet = null;
		ResultSet categoryResultSet = null;
		ResultSet picturesResultSet = null;
		PointOfInterest pointOfInterest = null;
		try {
			int aId = 0;
			String aName = null;
			String aDescription = null;
			double aLongitude = 0.0;
			double aLatitude = 0.0;
			String aPostalAddress = null;
			double aRating = 0;
			int aRatingCount = 1;
			String aRatingString = null;
			String aRatingCountString = null;
			String aCategoryId;
			Category category;
			Picture picture;
			
			poiResultSet = Database.executeQuery("SELECT * FROM PointsOfInterest WHERE id = " + id);
			poiResultSet.next();
			aId = Integer.parseInt(poiResultSet.getString("id"));
			aName = poiResultSet.getString("name").trim();
			aDescription = poiResultSet.getString("description").trim();
			aLongitude = Double.parseDouble(poiResultSet.getString("longitude"));
			aLatitude = Double.parseDouble(poiResultSet.getString("latitude"));
			aPostalAddress = poiResultSet.getString("postalAddress");
			aRatingString = poiResultSet.getString("rating");
			aRatingCountString = poiResultSet.getString("ratingCount");
			
			if (aPostalAddress == null) {
				aPostalAddress = "";
			} else {
				aPostalAddress = aPostalAddress.trim();					
			}
			aRatingString = poiResultSet.getString("rating");
			if (aRatingString == null) {
				aRating = 0.0;
			} else {
				aRating = Double.parseDouble(aRatingString);
			}
			aRatingCountString = poiResultSet.getString("ratingCount");
			if (aRatingCountString == null) {
				aRatingCount = 0;
			} else {
				aRatingCount = Integer.parseInt(aRatingCountString);
			}
			
			pointOfInterest = new PointOfInterest();
			pointOfInterest.setId(aId);
			pointOfInterest.setName(aName);
			pointOfInterest.setDescription(aDescription);
			pointOfInterest.setLongitude(aLongitude);
			pointOfInterest.setLatitude(aLatitude);
			pointOfInterest.setPostalAddress(aPostalAddress);
			pointOfInterest.setRating(aRating);
			pointOfInterest.setRatingCount(aRatingCount);
			
			categoryResultSet = Database.executeQuery("SELECT * FROM PointOfInterestCategories WHERE poiId = " + aId);
			while(categoryResultSet.next()) {
				aCategoryId = categoryResultSet.getString("categoryId");
				category = Category.loadCategoryById(aCategoryId);
				pointOfInterest.addCategory(category);
			}
			
			picturesResultSet = Database.executeQuery("SELECT * FROM PointOfInterestPictures WHERE poiId = " + aId);
			while(picturesResultSet.next()) {
				int aPictureId =  Integer.parseInt(picturesResultSet.getString("id"));
				picture = Picture.loadPictureById(aPictureId);
				pointOfInterest.addPicture(picture);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (poiResultSet != null) { try { poiResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (poiResultSet != null) { try { poiResultSet.close(); } catch (SQLException e) {} }
			if (categoryResultSet != null) { try { categoryResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (categoryResultSet != null) { try { categoryResultSet.close(); } catch (SQLException e) {} }
			if (picturesResultSet != null) { try { picturesResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (picturesResultSet != null) { try { picturesResultSet.close(); } catch (SQLException e) {} }
		}
		
		return pointOfInterest;
	}
	
	/**
	 * Loads all points of interest stored in the database.
	 * 
	 * @return a list of all points of interest stored in the database.
	 */
	public static List<PointOfInterest> loadAllPointsOfInterest() {
		ResultSet poiResultSet = null;
		ResultSet categoryResultSet = null;
		ResultSet picturesResultSet = null;
		List<PointOfInterest> pointOfInterestList = new ArrayList<PointOfInterest>();
		PointOfInterest pointOfInterest;
		
		try {
			int aId = 0;
			String aName = null;
			String aDescription = null;
			double aLongitude = 0.0;
			double aLatitude = 0.0;
			String aPostalAddress = null;
			double aRating = 0;
			int aRatingCount = 1;
			String aRatingString = null;
			String aRatingCountString = null;
			String aCategoryId;
			Category category;
			Picture picture;
			
			poiResultSet = Database.executeQuery("SELECT * FROM PointsOfInterest");
			while (poiResultSet.next()) {
				aId = Integer.parseInt(poiResultSet.getString("id"));
				aName = poiResultSet.getString("name").trim();
				aDescription = poiResultSet.getString("description").trim();
				aLongitude = Double.parseDouble(poiResultSet.getString("longitude"));
				aLatitude = Double.parseDouble(poiResultSet.getString("latitude"));
				aPostalAddress = poiResultSet.getString("postalAddress");
				
				if (aPostalAddress == null) {
					aPostalAddress = "";
				} else {
					aPostalAddress = aPostalAddress.trim();					
				}
				aRatingString = poiResultSet.getString("rating");
				if (aRatingString == null) {
					aRating = 0.0;
				} else {
					aRating = Double.parseDouble(aRatingString);
				}
				aRatingCountString = poiResultSet.getString("ratingCount");
				if (aRatingCountString == null) {
					aRatingCount = 0;
				} else {
					aRatingCount = Integer.parseInt(aRatingCountString);
				}
				
				pointOfInterest = new PointOfInterest();
				pointOfInterest.setId(aId);
				pointOfInterest.setName(aName);
				pointOfInterest.setDescription(aDescription);
				pointOfInterest.setLongitude(aLongitude);
				pointOfInterest.setLatitude(aLatitude);
				pointOfInterest.setPostalAddress(aPostalAddress);
				pointOfInterest.setRating(aRating);
				pointOfInterest.setRatingCount(aRatingCount);
				
				categoryResultSet = Database.executeQuery("SELECT * FROM PointOfInterestCategories WHERE poiId = " + aId);
				while(categoryResultSet.next()) {
					aCategoryId = categoryResultSet.getString("categoryId");
					category = Category.loadCategoryById(aCategoryId);
					pointOfInterest.addCategory(category);
				}
				categoryResultSet.getStatement().close();
				categoryResultSet.close();
				
				picturesResultSet = Database.executeQuery("SELECT * FROM PointOfInterestPictures WHERE poiId = " + aId);
				while(picturesResultSet.next()) {
					int aPictureId =  Integer.parseInt(picturesResultSet.getString("id"));
					picture = Picture.loadPictureById(aPictureId);
					pointOfInterest.addPicture(picture);
				}
				picturesResultSet.getStatement().close();
				picturesResultSet.close();
				
				pointOfInterestList.add(pointOfInterest);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (poiResultSet != null) { try { poiResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (poiResultSet != null) { try { poiResultSet.close(); } catch (SQLException e) {} }
			if (categoryResultSet != null) { try { categoryResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (categoryResultSet != null) { try { categoryResultSet.close(); } catch (SQLException e) {} }
			if (picturesResultSet != null) { try { picturesResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (picturesResultSet != null) { try { picturesResultSet.close(); } catch (SQLException e) {} }
		}
		
		return pointOfInterestList;		
	}
	
	/**
	 * Loads all points of interest that are assigned to a given category.
	 * 
	 * @param id the id of the category.
	 * @return all points of interest that are assigned to a given category.
	 */
	public static List<PointOfInterest> loadPointsOfInterestByCategory(String id) {
		ResultSet poiResultSet = null;
		ResultSet categoryResultSet = null;
		ResultSet picturesResultSet = null;
		List<PointOfInterest> pointOfInterestList = new ArrayList<PointOfInterest>();
		PointOfInterest pointOfInterest;
		
		try {
			int aId = 0;
			String aName = null;
			String aDescription = null;
			double aLongitude = 0.0;
			double aLatitude = 0.0;
			String aPostalAddress = null;
			double aRating = 0;
			int aRatingCount = 1;
			String aRatingString = null;
			String aRatingCountString = null;
			String aCategoryId;
			Category category;
			Picture picture;
			
			String sqlStatement = "SELECT * FROM PointsOfInterest WHERE id IN (SELECT poiId FROM PointOfInterestCategories WHERE categoryId = " + id + ")";
			poiResultSet = Database.executeQuery(sqlStatement);
			while (poiResultSet.next()) {
				aId = Integer.parseInt(poiResultSet.getString("id"));
				aName = poiResultSet.getString("name").trim();
				aDescription = poiResultSet.getString("description").trim();
				aLongitude = Double.parseDouble(poiResultSet.getString("longitude"));
				aLatitude = Double.parseDouble(poiResultSet.getString("latitude"));
				aPostalAddress = poiResultSet.getString("postalAddress");
				if (aPostalAddress == null) {
					aPostalAddress = "";
				} else {
					aPostalAddress = aPostalAddress.trim();					
				}
				aRatingString = poiResultSet.getString("rating");
				if (aRatingString == null) {
					aRating = 0.0;
				} else {
					aRating = Double.parseDouble(aRatingString);
				}
				aRatingCountString = poiResultSet.getString("ratingCount");
				if (aRatingCountString == null) {
					aRatingCount = 0;
				} else {
					aRatingCount = Integer.parseInt(aRatingCountString);
				}
				
				pointOfInterest = new PointOfInterest();
				pointOfInterest.setId(aId);
				pointOfInterest.setName(aName);
				pointOfInterest.setDescription(aDescription);
				pointOfInterest.setLongitude(aLongitude);
				pointOfInterest.setLatitude(aLatitude);
				pointOfInterest.setPostalAddress(aPostalAddress);
				pointOfInterest.setRating(aRating);
				pointOfInterest.setRatingCount(aRatingCount);
				
				categoryResultSet = Database.executeQuery("SELECT * FROM PointOfInterestCategories WHERE poiId = " + aId);
				while(categoryResultSet.next()) {
					aCategoryId = categoryResultSet.getString("categoryId");
					category = Category.loadCategoryById(aCategoryId);
					pointOfInterest.addCategory(category);
				}
				categoryResultSet.getStatement().close();
				categoryResultSet.close();
				
				picturesResultSet = Database.executeQuery("SELECT * FROM PointOfInterestPictures WHERE poiId = " + aId);
				while(picturesResultSet.next()) {
					int aPictureId =  Integer.parseInt(picturesResultSet.getString("id"));
					picture = Picture.loadPictureById(aPictureId);
					pointOfInterest.addPicture(picture);
				}
				picturesResultSet.getStatement().close();
				picturesResultSet.close();
				
				pointOfInterestList.add(pointOfInterest);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (poiResultSet != null) { try { poiResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (poiResultSet != null) { try { poiResultSet.close(); } catch (SQLException e) {} }
			if (categoryResultSet != null) { try { categoryResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (categoryResultSet != null) { try { categoryResultSet.close(); } catch (SQLException e) {} }
			if (picturesResultSet != null) { try { picturesResultSet.getStatement().close(); } catch (SQLException e) {} }
			if (picturesResultSet != null) { try { picturesResultSet.close(); } catch (SQLException e) {} }
		}
		
		return pointOfInterestList;		
	}
	
	/**
	 * Saves a single point of interest in the underlying database.
	 * 
	 * @param pointOfInterest the point of interest to be saved.
	 */
	public static void save(PointOfInterest pointOfInterest) {
		String sqlStatement;
		
		try {
			sqlStatement = "INSERT INTO PointsOfInterest (name, description, longitude, latitude, postalAddress, rating, ratingCount) VALUES(" +
					"'" + pointOfInterest.name + "', " +
					"'" + pointOfInterest.description + "', " +
					pointOfInterest.longitude + ", " +
					pointOfInterest.latitude + ", " +
					"'" + pointOfInterest.postalAddress + "', " +
					pointOfInterest.rating + ", " +
					pointOfInterest.ratingCount + ");";
			Database.executeUpdate(sqlStatement);
			
			sqlStatement = "DELETE FROM PointOfInterestCategories WHERE poiId = " + pointOfInterest.id;
			Database.executeUpdate(sqlStatement);
			
			for (Category category : pointOfInterest.getCategories()) {
				sqlStatement = "INSERT INTO PointOfInterestCategories (poiId, categoryId) VALUES(" +
						+ pointOfInterest.id + "," +
						+ category.getId() +")";
				Database.executeUpdate(sqlStatement);
			}
			
	        for (Picture picture : pointOfInterest.getPictures()) {
				Picture.savePicture(picture);
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Updates a single point of interest in the underlying database.
	 * 
	 * @param pointOfInterest the point of interest to be updated.
	 */
	public static void update(PointOfInterest pointOfInterest) {
		String sqlStatement;
		
		try {
			sqlStatement = "UPDATE PointsOfInterest " +
					"SET name = '" + pointOfInterest.name + "', " + 
					"description = '" + pointOfInterest.description + "', " +
					"longitude = " + String.valueOf(pointOfInterest.longitude) + ", " +
					"latitude = " + String.valueOf(pointOfInterest.latitude) + ", " +
					"postalAddress = '" + pointOfInterest.postalAddress + "', " +
					"rating = " + pointOfInterest.rating + ", " +
					"ratingCount = " + pointOfInterest.ratingCount + " " +
					"WHERE id = " + pointOfInterest.id;
			Database.executeUpdate(sqlStatement);

			sqlStatement = "DELETE FROM PointOfInterestCategories WHERE poiId = " + pointOfInterest.id;
			Database.executeUpdate(sqlStatement);

			for (Category category : pointOfInterest.getCategories()) {
				sqlStatement = "INSERT INTO PointOfInterestCategories (poiId, categoryId) VALUES(" +
						+ pointOfInterest.id + "," +
						+ category.getId() +")";
				Database.executeUpdate(sqlStatement);
			}

	        for (Picture picture : pointOfInterest.getPictures()) {
				Picture.savePicture(picture);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Deletes a single point of interest from the database.
	 * 
	 * @param pointOfInterest the point of interest to be deleted.
	 */
	public static void delete(PointOfInterest pointOfInterest) {
		String sqlStatement = "DELETE FROM PointsOfInterest WHERE id = " + pointOfInterest.getId();
		
		try {
			Database.executeUpdate(sqlStatement);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Returns the postal address of the point of interest.
	 * 
	 * @return the postal address of the point of interest.
	 */
	public String getPostalAddress() {
		return postalAddress;
	}

	/**
	 * Sets the postal address of the point of interest.
	 * 
	 * @param postalAddress the postal address of the point of interest.
	 */
	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	/**
	 * Returns the user rating of this point of interest.
	 * 
	 * @return the user rating of this point of interest.
	 */
	public double getRating() {
		return rating;
	}

	/**
	 * Sets the user rating of this point of interest. 
	 * 
	 * @param rating the user rating of this point of interest.
	 */
	public void setRating(double rating) {
		if (rating >= 0.0 && rating <= 5.0) {
			this.rating = rating;			
		}
	}

	/**
	 * Returns a list of all uploaded pictures of this point of interest.
	 * 
	 * @return a list of all uploaded pictures of this point of interest.
	 */
	public ArrayList<Picture> getPictures() {
		return pictures;
	}

	/**
	 * Sets a list of all uploaded pictures of this point of interest.
	 * 
	 * @param pictures a list of all uploaded pictures of this point of interest.
	 */
	public void setPictures(ArrayList<Picture> pictures) {
		this.pictures = pictures;
	}
	
	/**
	 * Adds a picture to the list of uploaded pictures of this point of interest.
	 * 
	 * @param picture a picture.
	 */
	public void addPicture(Picture picture) {
		pictures.add(picture);
	}
	
	/**
	 *  Removes a picture to the list of uploaded pictures of this point of interest.
	 *  
	 * @param picture a picture.
	 */
	public void removePicture(Picture picture) {
		pictures.remove(picture);
	}

	/**
	 * Returns the rating count of this point of interest.
	 * 
	 * @return the rating count of this point of interest.
	 */
	public int getRatingCount() {
		return ratingCount;
	}

	/**
	 * Sets the rating count of this point of interest.
	 * 
	 * @param ratingCount the rating count of this point of interest.
	 */
	public void setRatingCount(int ratingCount) {
		this.ratingCount = ratingCount;
	}
	
}
