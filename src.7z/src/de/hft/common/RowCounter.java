package de.hft.common;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;

/**
 * 
 * This class helps to count rows in a f:dataTable provided by JSF.  
 * 
 * @author Marcel Bruse
 *
 */
@ManagedBean(name = "rowCounter")
public class RowCounter implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/** A simple row counter for dataTables. */
	private transient int row = 0;
	
	/** A simple row counter for dataTables. */
	private transient int row1 = 0;
	
	/** A simple row counter for dataTables. */
	private transient int row2 = 0;
	
	/**
	 * Returns and increments the row counter.
	 * 
	 * @return the row count.
	 */
	public int getRow() {
		return ++row;
	}
	
	/**
	 * Returns and increments the row counter.
	 * 
	 * @return the row count.
	 */
	public int getRow1() {
		return ++row1;
	}
	
	/**
	 * Returns and increments the row counter.
	 * 
	 * @return the row count.
	 */
	public int getRow2() {
		return ++row2;
	}
	
}
