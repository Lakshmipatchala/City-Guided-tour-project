package de.hft.common;

import javax.faces.bean.ManagedBean;

import de.hft.data.Database;

/**
 * 
 * This class contains all system-scope utilities that can not be assigned to any other entity.
 * 
 * @author Marcel Bruse
 *
 */
@ManagedBean(name = "management")
public class Management {

	/**
	 * Checks whether the database is set up or not.
	 * 
	 * @return true, if the database is set up otherwise false.
	 */
	public boolean isSystemPrepared() {
		return Database.isSystemPrepared();
	}
	
}
