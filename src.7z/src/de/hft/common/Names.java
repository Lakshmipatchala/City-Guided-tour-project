package de.hft.common;

/**
 * 
 * This class is supposed to be used for internationalization. It provides all texts used on the GUI.
 * 
 * @author Marcel Bruse
 *
 */
public class Names {

	/**	Represents the internal name of the system  */
	public static final String SYSTEM_NAME = "MobileCityGuideServer";
	
}
