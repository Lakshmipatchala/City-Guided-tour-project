package de.hft.data;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * This is part of the database abstraction layer. It provides connections and
 * access to the underlying database. 
 * 
 * @author Marcel Bruse
 *
 */
public class Database {
	
	/** The database connection */
	private static Connection connection;
	
	/** The name of the database */
	private static String dbName = "MobileCityGuideDB";

	/**
	 * Opens a database connection if nessecary.
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static void openConnection() throws ClassNotFoundException, SQLException {
		if (connection == null || connection.isClosed()) {
			Class.forName("org.hsqldb.jdbc.JDBCDriver" );
			connection = DriverManager.getConnection("jdbc:hsqldb:file:" + dbName, "SA", "");
		}
	}
	
	/**
	 * This method returns a open connection to the database. 
	 * 
	 * @return a open connection to the database.
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		openConnection();
		return connection;
	}
	
	/**
	 * Closes the currently opened connection to the database.
	 */
	public static void closeConnection() {
		try {
			if (connection != null && !connection.isClosed()) {
				connection.createStatement().execute("SHUTDOWN");
				connection.close();			
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method checks whether the database with its tables has already been set up or not.
	 * 
	 * @return true, if the tables of the database are already created. Otherwise false.
	 */
	public static boolean isSystemPrepared() {
		String sqlStatement = "SELECT * FROM PointsOfInterest";
		try {
			openConnection();
			executeQuery(sqlStatement);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			return false;
		}
		return true;
	}
	
	/**
	 * Executes any valid SQL UPDATE statement with the currently open connection.
	 * If no connection is open, it will open one.
	 * 
	 * @param sqlStatement the statement to be executed.
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static void executeUpdate(String sqlStatement) throws ClassNotFoundException, SQLException {
		openConnection();
		Statement statement = connection.createStatement();
		statement.executeUpdate(sqlStatement);
		statement.close();
	}
	
	/**
	 * Executes any valid SQL QUERY statement with the currently opened connection.
	 * If no connection is open, it will open one. Afterwards it returns the result.
	 * 
	 * @param sqlStatement the statement to be executed.
	 * @return the result set of the query.
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static ResultSet executeQuery(String sqlStatement) throws ClassNotFoundException, SQLException {
		Statement statement;
		ResultSet resultSet = null;
		openConnection();
		statement = connection.createStatement();
		resultSet = statement.executeQuery(sqlStatement);
		
		return resultSet;
	}
	
	/**
	 * This is a special method to store BLOBs (binary large objects) into the underlying database.
	 * 
	 * @param table The table that stores the BLOB.
	 * @param field The field that stores the BLOB.
	 * @param key The id of the record which the BLOB belongs to.
	 * @param condition The name of the id field.
	 * @param fis The input stream of the BLOB.
	 * @param length The length of the BLOB in bytes.
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static void storeBLOB(String table, String field, String key, String condition, InputStream fis, long length) throws ClassNotFoundException, SQLException {
		openConnection();
		String sqlStatement = "UPDATE " + table + " SET " + field + " = ? " + " WHERE " + condition + " = " + key;
		PreparedStatement statement = connection.prepareStatement(sqlStatement);
		statement.setBinaryStream(1, fis, length);
		statement.executeUpdate();
		statement.close();
	}
	
}
