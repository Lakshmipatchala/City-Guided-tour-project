package de.hft.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import de.hft.model.Category;
import de.hft.model.PointOfInterest;
import de.hft.model.Route;

/**
 * This class provides functionalities to present and maintain routes by JSFs.
 * 
 * @author Marcel Bruse
 */

@ManagedBean(name = "routeHandler")
@SessionScoped
public class RouteHandler {

	/** The session scoped multi-purpose reference to a route. */
	private Route route;

	/**
	 * @return the reference to the current loaded route.
	 */
	public Route getRoute() {
		return route;
	}

	/**
	 * @param route The route to be focused in further processing
	 */
	public void setRoute(Route route) {
		this.route = route;
	}
	
	/**
	 * Returns all routes existing and stored.
	 * 
	 * @return
	 */
	public List<Route> getRouteList() {
		return Route.loadAllRoutes();
	}
	
	/**
	 * Marks a route to be edited. Therefore the route will be loaded from the
	 * database and assigned to the currently selected route. 
	 * 
	 * @return the navigation rule to the route editor.
	 */
	public String markToBeEdited() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String routeId = (String) reqmap.get("routeId");
		route = Route.loadRouteById(routeId);
		
		return "/faces/RouteEditor.xhtml?faces-redirect=true";
	}

	/**
	 * Marks a route to be deleted. Therefore the route will be loaded from the
	 * database and assigned to the currently selected route. 
	 * 
	 * @return the navigation rule to the route deletion dialog.
	 */
	public String markToBeDeleted() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String routeId = (String) reqmap.get("routeId");
		route = Route.loadRouteById(routeId);
		
		return "/faces/RouteDeletion.xhtml?faces-redirect=true";
	}
	
	/**
	 * Prepares the creation of a new route.
	 * 
	 * @return the navigation rule to the route editor.
	 */
	public String prepareCreation() {
		route = new Route();
		return "/faces/RouteEditor.xhtml?faces-redirect=true";
	}
	
	/**
	 * Persists the currently selected route in the database.
	 * It checks whether the route is already persistent or not.
	 * 
	 * @return the navigation rule to the list of routes.
	 */
	public String persist() {
		if (route.getId() == 0) {
			Route.save(route);
		} else {
			Route.update(route);
		}
		
		return "/faces/RouteList.xhtml?faces-redirect=true";
	}
	
	/**
	 * Checks whether the route is already persistent or not.
	 * 
	 * @return true, if the route is already persistent.
	 */
	public boolean isPersistent() {
		if (route != null) {
			return route.isPersistent();
		}
		return false;
	}
	
	/**
	 * Deletes the currently selected routes.
	 * 
	 * @return the navigation rule to the list of routes.
	 */
	public String deleteRoute() {
		Route.delete(route);
		return "/faces/RouteList.xhtml?faces-redirect=true";
	}
	
	/**
	 * Adds a point of interest to the currently selected route.
	 * 
	 * @return the navigation rule to the route editor.
	 */
	public String addPointOfInterest() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();

		String pointOfInterestId = (String) reqmap.get("pointOfInterestId");
		PointOfInterest pointOfInterest = PointOfInterest.loadPointOfInterestById(pointOfInterestId);

		route.addPointOfInterest(pointOfInterest);

		return "/faces/RouteEditor.xhtml?faces-redirect=true";
	}
	
	/**
	 * Removes a point of interest of the currently selected route.
	 */
	public void removePointOfInterest() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String pointOfInterestId = (String) reqmap.get("pointOfInterestId");
		
		ArrayList<PointOfInterest> toBeRemoved = new ArrayList<PointOfInterest>();
		List<PointOfInterest> pointOfInterestList = route.getPointsOfInterest();
		for (PointOfInterest pointOfInterest : pointOfInterestList) {
			if (String.valueOf(pointOfInterest.getId()).equals(pointOfInterestId)) {
				toBeRemoved.add(pointOfInterest);
			}
		}
		
		for (PointOfInterest pointOfInterest : toBeRemoved) {
			route.removePointOfInterest(pointOfInterest);
		}
	}
	
	/**
	 * Returns a list of all points of interest that are not assigned to the route yet.
	 * 
	 * @return a list of all points of interest that are not assigned to the route yet.
	 */
	public List<PointOfInterest> getNotAssignedPointsOfInterestList() {
		List<PointOfInterest> allPointsOfInterest = PointOfInterest.loadAllPointsOfInterest();
		List<PointOfInterest> routePointsOfInterest = route.getPointsOfInterest();
		ArrayList<PointOfInterest> toBeRemoved = new ArrayList<PointOfInterest>();
		
		for (PointOfInterest routePointOfInterest : routePointsOfInterest) {
			for (PointOfInterest pointOfInterest : allPointsOfInterest) {
				if (routePointOfInterest.equals(pointOfInterest)) {
					toBeRemoved.add(pointOfInterest);
				}
			}
		}
		
		allPointsOfInterest.removeAll(toBeRemoved);
		return allPointsOfInterest;
	}
	
	/**
	 * Checks whether the route contains all existing points of interest.
	 * 
	 * @return true, if the route contains all existing points of interest.
	 */
	public boolean isContainsAllPointsOfInterest() {
		List<PointOfInterest> allPointsOfInterest = PointOfInterest.loadAllPointsOfInterest();
		List<PointOfInterest> routePointsOfInterest = route.getPointsOfInterest();
		
		return allPointsOfInterest.size() == routePointsOfInterest.size();
	}
	
	/**
	 * Adds a category to the currently selected route.
	 * 
	 * @return the navigation rule to the route editor.
	 */
	public String addCategory() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();

		String categoryId = (String) reqmap.get("categoryId");
		Category category = Category.loadCategoryById(categoryId);

		route.addCategory(category);

		return "/faces/RouteEditor.xhtml?faces-redirect=true";
	}
	
	/**
	 * Removes a category from the currently selected route.
	 */
	public void removeCategory() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String categoryId = (String) reqmap.get("categoryId");
		
		ArrayList<Category> toBeRemoved = new ArrayList<Category>();
		List<Category> categories = route.getCategories();
		for (Category category : categories) {
			if (String.valueOf(category.getId()).equals(categoryId)) {
				toBeRemoved.add(category);
			}
		}
		
		for (Category category : toBeRemoved) {
			route.removeCategory(category);
		}
	}
	
	/**
	 * Moves up a point of interest in the list of assigned points of interest.
	 * This changes the order of the points of interest. 
	 */
	public void moveUpPointOfInterest() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		int row = Integer.parseInt(reqmap.get("row"));
		
		route.moveUpPointOfInterest(row - 1);
	}

	/**
	 * Moves down a point of interest in the list of assigned points of interest.
	 * This changes the order of the points of interest. 
	 */
	public void moveDownPointOfInterest() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		int row = Integer.parseInt(reqmap.get("row"));
		
		route.moveDownPointOfInterest(row - 1);
	}
		
	/**
	 * Returns all categories which the current point of interest NOT belongs to.
	 * 
	 * @return all categories which the current point of interest NOT belongs to.
	 */
	public List<Category> getNotAssignedCategoriesList() {
		List<Category> allCategories = Category.loadAllCategories();
		List<Category> routeCategories = route.getCategories();
		List<Category> toBeRemoved = new ArrayList<Category>();
		
		for (Category routeCategory : routeCategories) {
			for (Category category : allCategories) {
				if (category.equals(routeCategory)) {
					toBeRemoved.add(category);
				}
			}
		}
		
		allCategories.removeAll(toBeRemoved);
		return allCategories;
	}
	
	/**
	 * Checks if the route is in all existing categories.
	 * 
	 * @return true, if the route is in all existing categories.
	 */
	public boolean isInAllCategories() {
		List<Category> allCategories = Category.loadAllCategories();
		return allCategories.size() == route.getCategories().size();
	}
	
	/**
	 * Validates the value of a given estimated time. The value should lie
	 * between 0 h and 24 h.
	 * 
	 * @param pContext the context
	 * @param pToValidate the UI component
	 * @param pLatitude the estimated time
	 * @throws ValidatorException
	 */
	public void validateEstimatedTime(FacesContext pContext, UIComponent pToValidate, Object pLatitude) 
			throws ValidatorException {
		FacesMessage message;
		
		Double longitude = (Double) pLatitude;
		
		if (!(longitude >= 0.0 && longitude <= 24.0)) {
			message = new FacesMessage("The estimated time has to be a value between 0.0 hours and 24.0 hours!");
			throw new ValidatorException(message);
		}
	}
}
