package de.hft.data;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import de.hft.model.Category;

/**
 * This class implements all needed functionalities to delegate user commands
 * from the GUI to the underlying model. The CategoryHandler helps you to
 * create, read, list, edit and delete categories via the GUI. 
 * 
 * @author Marcel Bruse
 *
 */
@ManagedBean(name = "categoryHandler")
@SessionScoped
public class CategoryHandler {

	/** The currently selected category to manipulate */
	private Category category;

	/**
	 * Returns the currently selected category.
	 * 
	 * @return the currently selected category.
	 */
	public Category getCategory() {
		return category;
	}

	/**
	 * Sets the currently selected category.
	 * 
	 * @param category the currently selected category.
	 */
	public void setCategory(Category category) {
		this.category = category;
	}
	
	/**
	 * Returns a list of all categories stored in the database.
	 * 
	 * @return a list of all existing categories.
	 */
	public List<Category> getCategoryList() {
		return Category.loadAllCategories();
	}
	
	/**
	 * Marks a category to be edited by the GUI. Therefor it loads
	 * the category from the database first and sets it as current
	 * selected category.
	 * 
	 * @return the navigation rule to the category editor to open the category.
	 */
	public String markToBeEdited() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String categoryId = (String) reqmap.get("categoryId");
		category = Category.loadCategoryById(categoryId);
		
		return "/faces/CategoryEditor.xhtml?faces-redirect=true";
	}
	
	/**
	 * Instantiates a new category object and sets it as the currently
	 * selected category.
	 * 
	 * @return the navigation rule to the category editor to open the new category.
	 */
	public String prepareCreation() {
		category = new Category();
		return "/faces/CategoryEditor.xhtml?faces-redirect=true";
	}
	
	/**
	 * This method persists the currently selected category. If the category id is zero
	 * this indicated that the category has to be inserted into the database. Otherwise
	 * its attributes only have to be updated. 
	 * 	
	 * @return the navigation rule to the category list.
	 */
	public String persist() {
		if (category.getId() == 0) {
			Category.save(category);
		} else {
			Category.update(category);
		}
		
		return "/faces/CategoryList.xhtml?faces-redirect=true";
	}
	
	/**
	 * Performs the deletion of the currently selected category.
	 * 
	 * @return the navigation rule to the category list. 
	 */
	public String deleteCategory() {
		Category.delete(category);
		return "/faces/CategoryList.xhtml?faces-redirect=true";
	}
	
	/**
	 * Marks a category to be deleted. Therefore the currently selected category
	 * will be set.
	 * 
	 * @return the navigation rule to the category deletion dialog.
	 */
	public String markToBeDeleted() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String categoryId = (String) reqmap.get("categoryId");
		category = Category.loadCategoryById(categoryId);
		
		return "/faces/CategoryDeletion.xhtml?faces-redirect=true";
	}
	
	/**
	 * Checks if the currently selected category is persistent already or not.
	 * 
	 * @return true, if the currently selected category is persistent. Otherwise false.
	 */
	public boolean isPersistent() {
		if (category != null) {
			return category.isPersistent();
		}
		return false;
	}
	
}
