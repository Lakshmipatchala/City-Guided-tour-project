package de.hft.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import org.apache.commons.io.FilenameUtils;
import org.apache.myfaces.custom.fileupload.UploadedFile;

import de.hft.model.Category;
import de.hft.model.Picture;
import de.hft.model.PointOfInterest;

/**
 * This class implements all needed functionalities to delegate user commands
 * from the GUI to the underlying model. The PointOfInterestHandler helps you to
 * create, read, list, edit and delete points of interest via the GUI. 
 * 
 * @author Marcel Bruse
 *
 */
@ManagedBean(name = "pointOfInterestHandler")
@SessionScoped
public class PointOfInterestHandler {

	/** The currently selected point of interest to work on */
	private PointOfInterest pointOfInterest;
	
	/** A file that has been uploaded to assign it to the currently selected point of interest */
	private UploadedFile uploadedFile;

	/**
	 * Returns the currently selected point of interest if there is one.
	 * 
	 * @return the currently selected point of interest.
	 */
	public PointOfInterest getPointOfInterest() {
		return pointOfInterest;
	}

	/**
	 * Sets the currently selected point of interest.
	 * 
	 * @param pointOfInterest the point of interest to be set.
	 */
	public void setPointOfInterest(PointOfInterest pointOfInterest) {
		this.pointOfInterest = pointOfInterest;
	}
	
	/**
	 * Deletes the currently selected point of interest.
	 * 
	 * @return the navigation rule to the point of interest list.
	 */
	public String deletePointOfInterest() {
		PointOfInterest.delete(pointOfInterest);
		return "/faces/PointOfInterestList.xhtml?faces-redirect=true";
	}
	
	/**
	 * Returns a list of all existing points of interest.
	 * 
	 * @return a list of all existing points of interest.
	 */
	public List<PointOfInterest> getPointOfInterestList() {
		return PointOfInterest.loadAllPointsOfInterest();
	}
	
	/**
	 * Marks the currently selected point of interest to be edited and 
	 * opens it in the point of interest editor.
	 * 
	 * @return the navigation rule to the point of interest editor
	 */
	public String markToBeEdited() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String pointOfInterestId = (String) reqmap.get("pointOfInterestId");
		pointOfInterest = PointOfInterest.loadPointOfInterestById(pointOfInterestId);
		
		return "/faces/PointOfInterestEditor.xhtml?faces-redirect=true";
	}
	
	/**
	 * Marks the currently selected point of interest to be edited and
	 * opens it in the point of interest deletion dialog.
	 * 
	 * @return the navigation rule to the deletion dialog.
	 */
	public String markToBeDeleted() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String pointOfInterestId = (String) reqmap.get("pointOfInterestId");
		pointOfInterest = PointOfInterest.loadPointOfInterestById(pointOfInterestId);
		
		return "/faces/PointOfInterestDeletion.xhtml?faces-redirect=true";
	}
	
	/**
	 * Prepares the creation of a new point of interest by instantiating a new
	 * object of PointOfInterest.
	 * 
	 * @return the navigation rule to the point of interest editor.
	 */
	public String prepareCreation() {
		pointOfInterest = new PointOfInterest();
		return "/faces/PointOfInterestEditor.xhtml?faces-redirect=true";
	}
	
	/**
	 * Persists the currently selected point of interest. If the id of the point of
	 * interest is zero this indicates that the point of interest is not stored in
	 * the database yet.  
	 * 
	 * @return the navigation rule to the point of interest list.
	 */
	public String persist() {
		if (pointOfInterest.getId() == 0) {
			PointOfInterest.save(pointOfInterest);
		} else {
			PointOfInterest.update(pointOfInterest);
		}
		
		return "/faces/PointOfInterestList.xhtml?faces-redirect=true";
	}
	
	/**
	 * Checks whether the currently selected point of interest is persistent
	 * already or not.
	 * 
	 * @return true, if the currently selected point of interest is persistent.
	 * Otherwise false.
	 */
	public boolean isPersistent() {
		if (pointOfInterest != null) {
			return pointOfInterest.isPersistent();
		}
		return false;
	}
	
	/**
	 * Validates that the given longitude lies in the possible range of
	 * -180 and 180 degrees. 
	 * 
	 * @param pContext the faces context.
	 * @param pToValidate the UI component.
	 * @param pLongitude the longitude itself.
	 * @throws ValidatorException
	 */
	public void validateLongitude(FacesContext pContext, UIComponent pToValidate, Object pLongitude) 
			throws ValidatorException {
		FacesMessage message;
		
		Double longitude = (Double) pLongitude;
		
		if (!(longitude >= -180.0 && longitude <= 180.0)) {
			message = new FacesMessage("The longitude has to be a value between -180.0 and 180.0 degrees!");
			throw new ValidatorException(message);
		}
	}
	
	/**
	 * Validates that the given latitude lies in the possible range of
	 * -90 and 90 degrees. 
	 * 
	 * @param pContext the faces context.
	 * @param pToValidate the UI component.
	 * @param pLongitude the latitude itself.
	 * @throws ValidatorException
	 */
	public void validateLatitude(FacesContext pContext, UIComponent pToValidate, Object pLatitude) 
			throws ValidatorException {
		FacesMessage message;
		
		Double longitude = (Double) pLatitude;
		
		if (!(longitude >= -90.0 && longitude <= 90.0)) {
			message = new FacesMessage("The latitude has to be a value between -90.0 and 90.0 degrees!");
			throw new ValidatorException(message);
		}
	}
	
	/**
	 * Adds a category the currently selected point of interest.
	 * 
	 * @return the navigation rule to the point of interest editor.
	 */
	public String addCategory() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();

		String categoryId = (String) reqmap.get("categoryId");
		Category category = Category.loadCategoryById(categoryId);

		pointOfInterest.addCategory(category);

		return "/faces/PointOfInterestEditor.xhtml?faces-redirect=true";
	}
	
	/**
	 * Removes a category from the currently selectes point of interest.
	 */
	public void removeCategory() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String categoryId = (String) reqmap.get("categoryId");
		
		ArrayList<Category> toBeRemoved = new ArrayList<Category>();
		List<Category> categories = pointOfInterest.getCategories();
		for (Category category : categories) {
			if (String.valueOf(category.getId()).equals(categoryId)) {
				toBeRemoved.add(category);
			}
		}
		
		for (Category category : toBeRemoved) {
			pointOfInterest.removeCategory(category);
		}
	}
	
	/**
	 * Returns all categories which the current point of interest NOT belongs to.
	 * 
	 * @return all categories which the current point of interest NOT belongs to.
	 */
	public List<Category> getNotAssignedCategoriesList() {
		List<Category> allCategories = Category.loadAllCategories();
		List<Category> poiCategories = pointOfInterest.getCategories();
		List<Category> toBeRemoved = new ArrayList<Category>();
		
		for (Category poiCategory : poiCategories) {
			for (Category category : allCategories) {
				if (category.equals(poiCategory)) {
					toBeRemoved.add(category);
				}
			}
		}
		
		allCategories.removeAll(toBeRemoved);
		return allCategories;
	}
	
	/**
	 * Checks whether the currently selected point of interest is in all
	 * categories.
	 * 
	 * @return true, if the currently selected point of interest is in all
	 * categories.
	 */
	public boolean isInAllCategories() {
		List<Category> allCategories = Category.loadAllCategories();
		List<Category> poiCategories = pointOfInterest.getCategories();
		return allCategories.size() == poiCategories.size();
	}
	
	/**
	 * Resets all ratings of the currently selected point of interest.
	 */
	public void resetRatingCount() {
		pointOfInterest.setRatingCount(0);
		pointOfInterest.setRating(0.0);
	}
	
	/**
	 * Uploads a picture file and assigns it to the currently selected
	 * point of interest.
	 * 
	 * @return the navigation rule to the point of interest editor.
	 * @throws Exception
	 */
	public String uploadPictureFile() throws Exception {				
        String fileName = FilenameUtils.getName(uploadedFile.getName());
        byte[] bytes = uploadedFile.getBytes();
        
        Picture picture = new Picture();
        picture.setFileName(fileName);
        picture.setBytes(bytes);
        picture.setPointOfInterestId(pointOfInterest.getId());
        
        pointOfInterest.addPicture(picture);
        
		return "/faces/PointOfInterestEditor?faces-redirect=true";
	}

	/**
	 * Returns the uploaded file.
	 * 
	 * @return the uploaded file.
	 */
	public UploadedFile getUploadedFile() {
		return uploadedFile;
	}

	/**
	 * Sets the uploaded file.
	 * 
	 * @param uploadedFile the uploaded file.
	 */
	public void setUploadedFile(UploadedFile uploadedFile) {
		this.uploadedFile = uploadedFile;
	}
	
	/**
	 * Removes an uploaded picture. 
	 */
	public void removePicture() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String pictureId = (String) reqmap.get("pictureId");
		
		ArrayList<Picture> toBeRemoved = new ArrayList<Picture>();
		List<Picture> pictures = pointOfInterest.getPictures();
		for (Picture picture : pictures) {
			if (String.valueOf(picture.getId()).equals(pictureId)) {
				toBeRemoved.add(picture);
			}
		}
		
		for (Picture picture : toBeRemoved) {
			pointOfInterest.removePicture(picture);
			Picture.deletePicture(picture);
		}
		
	}
	
	/**
	 * Opens / Downloads a uploaded picture.
	 * 
	 * @throws IOException
	 */
	public void viewPicture() throws IOException {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> reqmap = fc.getExternalContext().getRequestParameterMap();
		
		String pictureId = (String) reqmap.get("pictureId");
		
		String uri = "/LoadPictureOfPointOfInterest?id=" + pictureId;
	    fc.getExternalContext().dispatch(uri);
	}
	
}
